<?php

return [
    'name' => 'SubscraptionUser'
];
