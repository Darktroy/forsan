<?php

return [
    'name' => 'BankAccounts'
];
