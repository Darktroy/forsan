<?php

return [
    'name' => 'PaymentType'
];
