<?php

return [
    'name' => 'Ticket'
];
