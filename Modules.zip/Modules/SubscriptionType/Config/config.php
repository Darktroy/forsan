<?php

return [
    'name' => 'SubscriptionType'
];
