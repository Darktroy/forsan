<?php

return [
    'name' => 'UserToSubscription'
];
