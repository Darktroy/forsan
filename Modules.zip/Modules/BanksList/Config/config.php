<?php

return [
    'name' => 'BanksList'
];
