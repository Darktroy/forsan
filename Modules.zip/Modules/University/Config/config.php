<?php

return [
    'name' => 'University'
];
